let a = 3
let b = 4


a == 3 ? console.log("yes") : console.log("no");
// if(a == 3) {
//     console.log("yes");
// } else {
//     console.log("No");
// }