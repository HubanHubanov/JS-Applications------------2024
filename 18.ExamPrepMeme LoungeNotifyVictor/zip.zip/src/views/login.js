import { login } from "../data/user.js";
import { html, render, page } from "../lib.js";
import { createSubmitHandler, updateNav } from "../util.js";

const loginTemplate = (onLogin) => html`
<section id="login">
            <form id="login-form" @submit=${onLogin}>
                <div class="container">
                    <h1>Login</h1>
                    <label for="email">Email</label>
                    <input id="email" placeholder="Enter Email" name="email" type="text">
                    <label for="password">Password</label>
                    <input id="password" type="password" placeholder="Enter Password" name="password">
                    <input type="submit" class="registerbtn button" value="Login">
                    <div class="container signin">
                        <p>Dont have an account?<a href="#">Sign up</a>.</p>
                    </div>
                </div>
            </form>
        </section>

`;

export function showLogin(ctx) {
  render(loginTemplate(createSubmitHandler(onLogin)));
}

async function onLogin({email, password}, form) {
    if(!email || !password) {
        return alert("Fill all fields")
    }

   await login(email, password);
    updateNav()
    page.redirect("/catalog")
}
